import java.io.IOException;

public class AdminMain extends AdminCall
{
	public static void main(String[] args) throws IOException
	{
		//new MovieManagement();
		//new MovieManagement();
		//ScreenManagement sm = new ScreenManagement();
		//AdminCall ac = new AdminCall();

		//vt.add(new MovieData("���˵���2", 19, 240));
		//vt.add(new MovieData("ž��2", 15, 180));
		//vt.add(new MovieData("�̴Ͼ���2", 0, 120));
	
		AmenuDisp();
	}
}